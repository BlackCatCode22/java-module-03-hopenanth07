//App.java
//Hope Nanthavongdouangsy 9/19/2025

public class App {
    public static void main(String[] args) {

        Cat myCat = new Cat();
        myCat.meow();
        myCat.name = "Stella";
        myCat.age = 8;
        System.out.println(Cat.MAX_LIVES);
        System.out.println(Cat.getCatCount());

        Dog myDog = new Dog("Jerry", 33);
        System.out.println(myDog.name + " " + myDog.age);

    }
}