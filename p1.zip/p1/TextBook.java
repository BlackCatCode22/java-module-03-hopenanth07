package p1;

public class TextBook {
    String titleBook;
    String authorBook;
    int pagesBook;
    int year;
}
