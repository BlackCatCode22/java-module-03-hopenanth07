package p1;

public class App {
    public static void main(String[] args) {
        System.out.println("\n This is the App Class! \n");
        // Create a Coffee Cup object
        CoffeeCup coffeeCup = new CoffeeCup();
        // use the object
        coffeeCup.sizeInOz = "24";


        System.out.println("\n The coffeecup size is " + coffeeCup.sizeInOz);

        // Create a new TextBook object
        TextBook textBook = new TextBook();

        // use the object
        textBook.titleBook = "The Lightning Thief";
        textBook.authorBook = "Rick Riodan";
        textBook.pagesBook = 375;
        textBook.year = 2005;

        // out textbook information in textBook
        System.out.println("\n The textBook object title is " + textBook.titleBook);
        System.out.println("\n The textBook object author is " + textBook.authorBook);
        System.out.println("\n The textBook object pages is " + textBook.pagesBook);
        System.out.println("\n The textBook object year is " + textBook.year);

    }
}
