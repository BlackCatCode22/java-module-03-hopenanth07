public class ItalianChef {
    public void makeChicken() {
        System.out.println("The chef makes a delicious chicken");
    }
    public void makeSpecialDish() {
        System.out.println("The chef makes eggplant parm");
    }
    public void makePasta() {
        System.out.println("The chef makes pasta");
    }
}
