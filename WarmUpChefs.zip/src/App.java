// App.java

// Hope Nanthavongdouangsy 9/16/2025


public class App {
    public static void main(String[] args) {
        NormalChef normalChef = new NormalChef();
        normalChef.makeSpecialDish();

        ItalianChef italianChef = new ItalianChef();
        italianChef.makePasta();

        ChineseChef chineseChef = new ChineseChef();
        chineseChef.makeSpecialDish();
    }
}